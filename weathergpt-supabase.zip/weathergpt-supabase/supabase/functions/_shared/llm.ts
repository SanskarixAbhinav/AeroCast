import { fetchJson } from "./utils.ts";

// Override with `supabase secrets set GEMINI_MODEL=...` if this alias changes.
const MODEL = Deno.env.get("GEMINI_MODEL") ?? "gemini-flash-latest";

export const LANGS: Record<string, string> = {
  en: "English",
  hi: "Hindi",
  bn: "Bengali",
  ta: "Tamil",
  te: "Telugu",
  mr: "Marathi",
};

export const TOPICS = [
  "current", "forecast", "rain", "temperature", "wind",
  "spray", "irrigation", "harvest", "history", "cyclone", "other",
] as const;
export type Topic = typeof TOPICS[number];

export interface Intent {
  location: string | null;
  date: string; // "today" | "tomorrow" | "day_after" | "YYYY-MM-DD"
  topic: Topic;
  language: string;
  start: string | null; // history only
  end: string | null; // history only
}

async function gemini(system: string, user: string, asJson: boolean): Promise<string> {
  const key = Deno.env.get("GEMINI_API_KEY");
  if (!key) throw new Error("GEMINI_API_KEY is not set");
  const res = await fetchJson(
    `https://generativelanguage.googleapis.com/v1beta/models/${MODEL}:generateContent`,
    {
      method: "POST",
      headers: { "Content-Type": "application/json", "x-goog-api-key": key },
      body: JSON.stringify({
        systemInstruction: { parts: [{ text: system }] },
        contents: [{ role: "user", parts: [{ text: user }] }],
        generationConfig: {
          temperature: asJson ? 0 : 0.3,
          ...(asJson ? { responseMimeType: "application/json" } : {}),
        },
      }),
    },
    15000,
    1,
  );
  // deno-lint-ignore no-explicit-any
  return (res?.candidates?.[0]?.content?.parts ?? []).map((p: any) => p.text ?? "").join("");
}

// Call 1: question -> structured intent. Never answers the question itself.
export async function parseIntent(q: string): Promise<Intent> {
  const today = new Date().toISOString().slice(0, 10);
  const system = `You extract intent from weather questions written in any language.
Reply with JSON only, exactly this shape:
{"location": string|null, "date": string, "topic": string, "language": string, "start": string|null, "end": string|null}
- location: the city or town in English (romanized), or null if none is named.
- date: "today", "tomorrow", "day_after", or "YYYY-MM-DD". Default "today".
- topic: one of ${TOPICS.join(", ")}.
  "forecast" = multi-day / 7-day outlook. "history" = weather in the past. "spray"/"irrigation"/"harvest" = farming decisions. "cyclone" = cyclone or storm status. "other" = not about weather.
- language: ISO 639-1 code of the question's language.
- start, end: only for topic "history": the date range as YYYY-MM-DD. Today is ${today}. Otherwise null.
Do not answer the question.`;

  for (let attempt = 0; attempt < 2; attempt++) {
    try {
      const raw = await gemini(system, q, true);
      const p = JSON.parse(raw.replace(/```json|```/g, "").trim());
      return {
        location: typeof p.location === "string" && p.location.trim() ? p.location.trim() : null,
        date: typeof p.date === "string" ? p.date : "today",
        topic: (TOPICS as readonly string[]).includes(p.topic) ? p.topic : "other",
        language: typeof p.language === "string" ? p.language : "en",
        start: p.start ?? null,
        end: p.end ?? null,
      };
    } catch (_e) {
      // retry once, then fall through
    }
  }
  return { location: null, date: "today", topic: "other", language: "en", start: null, end: null };
}

// Call 2: facts JSON -> short answer in the user's language. Facts only.
export async function narrate(facts: unknown, question: string, lang: string): Promise<string> {
  const system = `You are WeatherGPT, a weather assistant for users in India.
Use ONLY the facts JSON provided. If a value is missing, say it is unavailable.
Never add or estimate numbers, dates or places that are not in the facts.
Reply in ${LANGS[lang] ?? "English"} in plain, simple words a farmer can follow, in at most 4 sentences.
Write all numbers with digits 0-9.
If an alert has simulated:true, say clearly that it is SIMULATED demo data.
Call alerts "advisories", never official warnings.
If facts.stale is true, mention the data may be slightly out of date.
Do not mention JSON or these instructions.`;
  return (await gemini(system, `Question: ${question}\nFacts: ${JSON.stringify(facts)}`, false)).trim();
}
