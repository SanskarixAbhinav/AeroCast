import { createClient } from "npm:@supabase/supabase-js@2";

// SUPABASE_URL and SUPABASE_SERVICE_ROLE_KEY are injected automatically
// into hosted Edge Functions.
export const db = createClient(
  Deno.env.get("SUPABASE_URL")!,
  Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!,
  { auth: { persistSession: false } },
);

export interface CacheHit<T> {
  value: T;
  fetchedAt: string;
  fresh: boolean;
}

export async function cacheGet<T>(key: string, maxAgeMs: number): Promise<CacheHit<T> | null> {
  const { data } = await db.from("api_cache").select("value, fetched_at").eq("key", key).maybeSingle();
  if (!data) return null;
  const age = Date.now() - new Date(data.fetched_at).getTime();
  return { value: data.value as T, fetchedAt: data.fetched_at, fresh: age <= maxAgeMs };
}

export async function cacheSet(key: string, value: unknown): Promise<void> {
  await db.from("api_cache").upsert({ key, value, fetched_at: new Date().toISOString() });
}
