# WeatherGPT backend on Supabase

Edge Functions (Deno/TypeScript) + Postgres. No servers to run.

```
supabase/
├── migrations/20260925000000_init.sql   # api_cache, cyclone_bulletins (seeded, SIMULATED), chat_logs
└── functions/
    ├── _shared/
    │   ├── utils.ts      # CORS, json(), fetchJson() with timeout + retry
    │   ├── db.ts         # service-role client + Postgres cache helpers
    │   ├── location.ts   # Open-Meteo geocoding (cached 30 days)
    │   ├── weather.ts    # forecast + archive, cache, stale fallback
    │   ├── alerts.ts     # rain / heat / wind thresholds + cyclone bulletin from DB
    │   ├── advisory.ts   # spray / irrigation / harvest rules
    │   ├── dates.ts      # day-hint resolution, history range clamp
    │   ├── llm.ts        # Gemini: parseIntent() and narrate()
    │   └── guard.ts      # number check on LLM output + template fallback
    ├── chat/index.ts     # POST /chat  (the pipeline)
    └── health/index.ts   # GET /health
```

## Deploy (about 15 minutes)

1. Create a project at supabase.com and note its **project ref**.
2. In this folder (use `npx supabase@latest ...` if you don't have the CLI installed):

```bash
supabase login
supabase init                      # creates supabase/config.toml; keeps the files here
supabase link --project-ref <ref>
supabase db push                   # creates the tables + seeds the demo cyclone bulletin
supabase secrets set GEMINI_API_KEY=<your key>
# optional, if the default model alias stops working:
# supabase secrets set GEMINI_MODEL=<current flash model id from Google's docs>
supabase functions deploy chat   --no-verify-jwt
supabase functions deploy health --no-verify-jwt
```

`SUPABASE_URL` and `SUPABASE_SERVICE_ROLE_KEY` are injected into hosted functions automatically.

## Test

```bash
BASE=https://<ref>.supabase.co/functions/v1

curl $BASE/health

curl -X POST $BASE/chat -H "Content-Type: application/json" \
  -d '{"q":"Will it rain tomorrow in Kolkata?","lang":"en"}'

curl -X POST $BASE/chat -H "Content-Type: application/json" \
  -d '{"q":"Is it safe to spray pesticides in Kolkata tomorrow?","lang":"hi"}'

# simulated cyclone (also triggers if the question is about a cyclone)
curl -X POST $BASE/chat -H "Content-Type: application/json" \
  -d '{"q":"Any cyclone near Kolkata?","lang":"bn"}'

curl -X POST $BASE/chat -H "Content-Type: application/json" \
  -d '{"q":"How much rain did Mumbai get last July?","lang":"en"}'
```

Local run (needs Docker): `supabase start`, put `GEMINI_API_KEY=...` in `supabase/.env.local`, then
`supabase functions serve --env-file supabase/.env.local --no-verify-jwt`.

## Contract

```jsonc
// POST /chat
{ "q": "Will it rain tomorrow in Kolkata?", "lang": "en", "demo": "cyclone" /* optional */ }

// 200
{
  "answer": "...",                       // LLM text, or a plain template if the guard trips
  "facts":  { "location": "...", "day": {...}, "current": {...}, "flags": {...}, "cyclone": {...} },
  "alerts": [{ "type": "heavy_rain", "level": "orange", "date": "...", "message": "...", "simulated": false, "official": false }],
  "meta":   { "source": "Open-Meteo", "fetched_at": "...", "from_cache": false, "stale": false }
}
```

Draw the data card from `facts`, never from `answer`. `lang` is one of `en hi bn ta te mr`.

## Frontend call

```js
const res = await fetch("https://<ref>.supabase.co/functions/v1/chat", {
  method: "POST",
  headers: { "Content-Type": "application/json" },
  body: JSON.stringify({ q, lang }),
});
const { answer, facts, alerts, meta } = await res.json();
```

Edge Functions can't serve HTML pages, so host the `frontend/` folder separately
(Netlify, Vercel, GitHub Pages, or open it locally). CORS is already open.

## How the anti-hallucination path works

1. Gemini call 1 returns intent JSON only (location, date hint, topic, language).
2. Code geocodes, fetches Open-Meteo, and computes alerts and advisory flags.
3. Gemini call 2 gets only the facts JSON and must narrate from it.
4. `guard.ts` rejects any answer containing a number that isn't in the facts
   (allowing rounding) and swaps in a template answer built from the facts.
5. If Gemini is down, the template answer is used. If Open-Meteo is down, the last
   cached copy is served (`meta.stale: true`), otherwise an "unavailable" message.

## Tuning and limits

- Thresholds: `THRESHOLDS` in `alerts.ts`, `RULES` in `advisory.ts`. Spray values are from
  the plan; irrigation and harvest values are starting points to check with an agronomy source.
- Alert colours (yellow/orange/red) are simple MVP tiers. Alerts are advisories, not official warnings.
- `--no-verify-jwt` makes `/chat` public. It has a per-IP limit of 20 requests/minute
  (`RATE_LIMIT_PER_MIN` in `chat/index.ts`) to protect the Gemini quota. To require a
  token instead, deploy without the flag and send the project's anon key as `Authorization: Bearer <key>`.
- Static messages (help, "which city?") are translated by Gemini; if Gemini fails they appear in English.
- The archive API lags about 5 days, so very recent "history" questions are refused.
- Open-Meteo's free API is for non-commercial use.
- Tables are only reachable by the service role (RLS on, no policies).
